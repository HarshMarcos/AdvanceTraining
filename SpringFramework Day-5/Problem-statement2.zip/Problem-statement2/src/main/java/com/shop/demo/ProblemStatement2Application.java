package com.shop.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.shop.demo.ProblemStatement2Application;

@SpringBootApplication
@EntityScan("com.shop.demo.model")
//@ComponentScan(basePackages= {"com.shop.demo"})
@EnableJpaRepositories(basePackages={"com.shop.demo.repository"})
public class ProblemStatement2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProblemStatement2Application.class, args);
	}

}
