package bean;

import java.util.Date;
import java.util.HashMap;

public class Order {
	
	private int order_id;
	private int book_code;
	private String cust_name;
	private String phone_no;
	private String address;
	private String order_date;
	private int quantity;
	private Double confNumber;
	private HashMap<String, Integer>products;
	
	public Order() {
		confNumber = (1000000 + (Math.random()*(9999999 - 1000000)));
		products = new HashMap<String, Integer>();
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	public int getBook_code() {
		return book_code;
	}

	public void setBook_code(int book_code) {
		this.book_code = book_code;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public String getPhone_no() {
		return phone_no;
	}

	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getOrder_date() {
		return order_date;
	}

	public void setOrder_date(String order_date) {
		this.order_date = order_date;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Double getConfNumber() {
		return confNumber;
	}

	public void setConfNumber(Double confNumber) {
		this.confNumber = confNumber;
	}

	public HashMap<String, Integer> getProducts() {
		return products;
	}

	public void setProducts(HashMap<String, Integer> products) {
		this.products = products;
	}
	
	
	
	
	
	

}
