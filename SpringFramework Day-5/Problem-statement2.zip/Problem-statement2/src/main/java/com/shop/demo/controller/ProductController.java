package com.shop.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.shop.demo.model.Product;
import com.shop.demo.repository.ProductRepository;

@RestController
public class ProductController {

	@Autowired
	private ProductRepository pRepo;
	
	@GetMapping({"/list", "/"})
	public ModelAndView getAllProduct() {
		ModelAndView mav = new ModelAndView("list-product");
		mav.addObject("product", pRepo.findAll());
		return mav;
	}
	
	@GetMapping("/addproductForm")
	public ModelAndView addEmployeeForm() {
		ModelAndView mav = new ModelAndView("add-product-form");
		Product newProduct = new Product();
		mav.addObject("Product", newProduct);
		return mav;
	}
	
	@GetMapping("/findproduct")
	public String findproduct(@RequestParam int ProductID) {
		pRepo.findById(ProductID);
		return "redirect:/list";
	}
	
	
	@GetMapping("/showUpdateForm")
	public ModelAndView showUpdateForm(@RequestParam int ProductID) {
		ModelAndView mav = new ModelAndView("add-product-form");
		Product product = pRepo.findById(ProductID).get();
		mav.addObject("product", product);
		return mav;
	}
	
	@GetMapping("/deleteproduct")
	public String deleteproduct(@RequestParam int ProductID) {
		pRepo.deleteById(ProductID);
		return "redirect:/list";
	}
}

