package constants;

public class IOnlineBookStoreConstants {
	public static String CONTENT_TYPE_TEXT_HTML = "text/html";

}
