package com.shoppingcartapplication.dao;

import java.util.List;

import com.shoppingcartapplication.model.Product;

public interface ProductDAO {
	
	public void addProduct(Product p);
	public void updateProduct(Product p);
	public List<Product> listProducts();
	public Product getProductById(int ProductID);
	public void removeProduct(int ProductID);
	
}
